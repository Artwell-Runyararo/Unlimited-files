<?php
session_start();
if (isset($_SESSION['email'])) {
    header("location:http://localhost/Mines/php/dashboard.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
    <style>
        .toast {
            opacity: 1 !important;
        }

        #toast-container>div {
            opacity: 1 !important;
        }
    </style>
</head>

<body style="transition: 0.3s;">
    <!-- Login Section -->
    <div class="container">
        <div class="row ">
            <!-- Hidden Column -->
            <div class="col-sm col-md col-lg"></div>
            <!-- End of Hidden Column -->

            <!-- 1st Column -->
            <div class="col-sm-12 col-md-9 col-lg-5 vertical">

                <!-- panel -->
                <div class="panel card">
                    <!-- panel header -->
                    <div class="panel-heading bg-dark bg-gradient">
                        <div class="panel-title  text-light pt-2">
                            <h4 class="small"><strong>Adminstration Sign in</strong></h4>
                        </div>
                    </div>
                    <!-- End of panel header -->
                    <!-- panel body -->
                    <div class="panel-body">
                        <!-- Login Form Section -->
                        <form class="p-5" method="POST" action="">
                            <!-- Email -->
                            <div class="form-group">
                                <label id="cc" class="text-muted" for=""><i  id="cc"  class="fa fa-envelope"></i> Email</label>
                                <input class="form-control" required type="text" name="email" id="email" placeholder="enter your email address">
                            </div>
                            <!-- End of Email -->
                            <!-- Password -->
                            <div class="form-group">
                                <label class="text-muted" for=""><i class="fa fa-key"></i> Password</label>
                                <input class="form-control" required type="password" name="password" id="password" placeholder="enter your password">
                            </div>
                            <!-- End of Password -->
                            <!-- Remember Me -->
                            <div class="form-group">
                                <input id="check" disabled class="" type="checkbox" name="remember">
                                <label class="text-muted box-remember" for="check"> Remember me</label>
                            </div>
                            <!-- End of Remember Me -->
                            <!-- Submit -->
                            <div class="form-group">
                                <button type="button" id="btn" name="btn" class="btn bg-dark bg-gradient text-light btn-block border p-3"><i class="glyphicon glyphicon-log-in"></i> <strong> Log In</strong></button>
                            </div>
                            <!-- End of Submit-->
                            <!-- Forgot password -->
                            <div class="form-group">
                                <a style="color: #ffc107 !important;" class="text-dark" href="##"><strong>Forget your password?</strong></a>
                            </div>
                            <!-- End of Forgot password -->
                            <div id="error"></div>
                        </form>
                        <!-- End of Login Form Section -->
                    </div>
                    <!-- End of panel body -->
                </div>
                <!-- End of panel -->
                <!-- Already have account -->
                <!--<p class="text-muted">If you are not yet a member please contact your superadminstrator <a class="text-dark" href="#"><strong> Contact</strong></a></p>-->
                <!-- End of Already have account -->
            </div>
            <!-- End of 1st Column -->
            <!-- Hidden Column -->
            <div class="col-sm col-md col-lg"></div>
            <!-- End of Hidden Column -->
        </div>
    </div>
    <!-- End of Login Section -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <!-- Ajax Query -->
    <script src="">
        toastr.options = {
            "closeButton": false,
            "debug": false,
            "newestOnTop": false,
            "progressBar": false,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "1000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "swing",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
        
            $('#btn').click(function() {
                var email = $('#email').val();
                var password = $('#password').val();
                if ($.trim(email).length > 0 && $.trim(password).length > 0) {
                    $.ajax({
                        url: "http://localhost/Mines/auth/server.php",
                        method: "POST",
                        data: {
                            email: email,
                            password: password
                        },
                        cache: false,
                        beforeSend: function() {
                            toastr.info('Connecting...');
                        },
                        success: function(data) {
                            if (data) {
                                window.location = "http://localhost/Mines/php/dashboard.php";
                            } else {
                                toastr.error('Invalid email address or password');
                                $('#email').focus();
                            }
                        }
                    });
                } else {
                    toastr.error('Insert all fields');
                    $('#email').focus();
                }
            });
        });
    </script>
    <!-- Ajax Qeuery -->
</body>

</html>