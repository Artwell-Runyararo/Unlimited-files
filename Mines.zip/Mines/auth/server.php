<?php
session_start();
$con = mysqli_connect("localhost", "id18231917_root", "Runyararoartwell1996;", "id18231917_zdamwu_system_database");

if (isset($_POST['email']) && $_POST['email'] != '' && isset($_POST['password']) && $_POST['password'] != '') {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    $query = "SELECT * FROM adminstration_users WHERE email = '$email' AND security_key ='$password'";
    $result = mysqli_query($con, $query);
    $num_row = mysqli_num_rows($result);
    if ($num_row > 0) {
        $data = mysqli_fetch_array($result);
        $_SESSION["email"] = $data["email"];
        echo $data["email"];
    }
}

// logout 
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['email']);
    header('location:http://localhost/Mines/');
    exit;
}
