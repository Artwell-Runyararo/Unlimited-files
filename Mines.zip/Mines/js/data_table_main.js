$(document).ready(function() {
    $('#table_id').DataTable({
        ajax: '../php/results.json',
        'columns': [
            { 'posts': 'mbr_number' },
            { 'posts': 'mbr_fname' },
            { 'posts': 'mbr_surname' },
            { 'posts': 'gender' },
            { 'posts': 'branch_name' },
            { 'posts': 'contact' },
            { 'posts': 'mbr_id_number' },
            { 'posts': 'work_number' },
            { 'posts': 'mbr_dob' },
            { 'posts': 'position' },
            { 'posts': 'date_joined' },
            { 'posts': 'job_grade' }
        ]
    });
});