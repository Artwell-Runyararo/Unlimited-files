$(document).ready(function() {
    $('#myTable').DataTable({
        dom: 'Blfrtip',
    });
    $('.buttons-excel, .buttons-print, .buttons-csv, .buttons-pdf, .buttons-copy').each(function() {
        $(this).removeClass('btn-default').addClass('btn bg-secondary bg-gradient text-light mt-3 mb-3');
    });
});