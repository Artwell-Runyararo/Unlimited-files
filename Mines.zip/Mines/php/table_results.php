<!doctype html>
<html>

<head>
    <title>PHP Convert Data from MySQL to JSON - result.json file </title>
</head>

<body>
    <?php
    include '../database/connection.php';
    $response = array();
    $posts = array();
    $query = "SELECT  members_registered.mbr_number,members_registered.mbr_fname, members_registered.mbr_surname,members_registered.gender,members_registered.contact,members_registered.mbr_dob,members_registered.mbr_id_number,members_registered.position,members_registered.date_joined,members_registered.work_number,members_registered.job_grade, branch.branch_name
    FROM members_registered
    JOIN branch
    ON members_registered.branch_id = branch.branch_id";


    $result = mysqli_query($con, $query);
    while ($row = mysqli_fetch_array($result)) {
        $mbr_no = $row['mbr_number'];
        $mbr_name = $row['mbr_fname'];
        $mbr_surname = $row['mbr_surname'];
        $mbr_gender = $row['gender'];
        $mbr_branch = $row['branch_name'];
        $mbr_contact = $row['contact'];
        $mbr_id = $row['mbr_id_number'];
        $mbr_workNo = $row['work_number'];
        $mbr_DOB = $row['mbr_dob'];
        $mbr_position = $row['position'];
        $mbr_DateJoined = $row['date_joined'];
        $mbr_jobGrade = $row['job_grade'];

        $posts[] = array(
            'mbr_number' => $mbr_no, 'mbr_fname' => $mbr_name, 'mbr_surname' => $mbr_surname,
            'gender' => $mbr_gender, 'branch_name' => $mbr_branch, 'contact' => $mbr_contact, 'mbr_id_number' =>  $mbr_id,
            'work_number' =>  $mbr_workNo, 'mbr_dob' =>   $mbr_DOB, 'position' =>  $mbr_position, 'date_joined' =>   $mbr_DateJoined,
            'job_grade' =>   $mbr_jobGrade
        );
    }
    $response['members_info'] = $posts;
    $fp = fopen('results.json', 'w');
    fwrite($fp, json_encode($response));
    fclose($fp);
    ?>
</body>

</html>