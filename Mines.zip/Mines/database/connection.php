
<?php
session_start();
$host = "localhost"; 
$user = "id18231917_root";
$password = "Runyararoartwell1996;"; 
$dbname = "id18231917_zdamwu_system_database"; 

$con = mysqli_connect($host, $user, $password,$dbname);
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}