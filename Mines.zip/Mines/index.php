<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZDAMWU Adminstration Log In</title>
    <!-- Bootstrap 3 -->
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <!--End of Bootstrap 3 -->
    <!-- Bootstrap theme-->
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-theme.min.css">
    <!-- End of Bootstrap theme-->
    <!-- Font awesome -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!-- End of font awesome -->
    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- End of Bootstrap 4 -->
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- End of Bootstrap 5 -->
    <!-- Main Css -->
    <link rel="stylesheet" href="css/dist/style.css">
    <!-- End of Main Css -->
    <!-- Ajax -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Ajax -->
    <style>
        input {
            height: 30px !important;
            border-radius: 4px !important;
        }

        ::placeholder {
            color: rgba(185, 185, 185, 0.466) !important;
        }

        input[type=text]:focus {
            border-color: #ffc107;
            box-shadow: 0 0 8px 0 #ffc107;
        }

        input[type=password]:focus {
            border-color:  #ffc107;
            box-shadow: 0 0 8px 0  #ffc107;
        }
    </style>
</head>

<body style="transition: 0.3s;">
    <!-- Header Php file included here-->
    <?php include('./includes/header.php'); ?>
    <!-- End of Header Php file included here-->

    <!-- section 1 -->
    <?php include('./auth/admin_login.php'); ?>
    <!-- End of section 1 -->

    <!-- Footer -->
    <?php include('./includes/footer.php'); ?>
    <!-- End of Footer -->

    <!-- Bootstrap 3 -->
    <script src="./assets/bootstrap/js/bootstrap.js"></script>
    <script src="./assets/bootstrap/js/bootstrap.min.js"></script>
    <!-- End of Boostrap 3 -->
    <!-- Bootstrap 4 script -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <!-- End of Bootstrap 4 script -->
    <!-- Bootstrap 5 script -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- End of Bootstrap 5 script -->
    <!-- JQuery -->
    <!-- Ajax -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Ajax -->
</body>

</html>