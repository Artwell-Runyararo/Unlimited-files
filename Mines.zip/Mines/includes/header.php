<!DOCTYPE html>
<html lang="en">

<body>
    <div class="container-fluid  p-0 m-0">
        <div class="row p-0 m-0">
            <div class="col-sm col-md col-lg  rounded-0 p-0 m-0">
                <div class="panel bg-dark bg-gradient border-0 p-0 m-0 rounded-0">
                    <div class="panel-heading pt-4 rounded-0">
                        <div class="panel-title rounded-0">
                            <h5 class="text-uppercase text-light"><marquee behavior="" direction="">Zimbabwe Diamonds & Allied Minerals Workers Union</marquee></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>