<!DOCTYPE html>
<html lang="en">

<body>
    <div class="container">
        <div class="row">
            <div class="col-sm col-md col-lg d-flex justify-content-center pt-5">
              <p class="text-muted small">&copy; 2021 All copyrights reserved. Zimbabwe Diamonds & Allied Minerals Workers Union.</p>
            </div>
        </div>
    </div>
</body>

</html>