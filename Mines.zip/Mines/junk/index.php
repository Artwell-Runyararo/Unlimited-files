<?php
/*
 * Database settings
 */
include('../auth/server.php');


if (!isset($_SESSION["email"])) {
    header("location: http://localhost/Mines/");
}


define("DB_SERVER", "localhost");
define("DB_NAME", "id18231917_zdamwu_system_database");
define("DB_USERNAME", "id18231917_root");
define("DB_PASSWORD", "Runyararoartwell1996;");

try {
    $db = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
} catch (PDOException $e) {
    echo "Error!: " . $e->getMessage() . "<br/>";
    exit();
} ?>
<!DOCTYPE html>
<html>

<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- Bootstrap 3 -->
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <!--End of Bootstrap 3 -->
    <!-- Bootstrap theme-->
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-theme.min.css">
    <!-- End of Bootstrap theme-->
    <!-- Font awesome -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!-- End of font awesome -->
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- End of Bootstrap 5 -->
    <!-- Main Css -->
    <!-- <link rel="stylesheet" href="../css/dist/dashboard.css"> -->
    <link rel="stylesheet" href="../css/dashboard.css">
    <!-- End of Main Css -->
    <!-- Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- End of Font -->
    <!-- Data_tables Links -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
    <!-- End of Data_tables Links -->
    <style>
        a:hover,
        a:focus {
            text-decoration: none !important;
            outline: none !important;
        }

        .vertical-tab .nav-tabs {
            display: table-cell !important;
            width: 25%;
            /* min-width: 25%;
            padding: 15px 0; */
            border: none !important;
        }

        .vertical-tab .nav-tabs li {
            float: none !important;
        }

        .vertical-tab .nav-tabs li a {
            border-radius: none !important;
            border: none !important;
            z-index: 1 !important;
            transition: all 0.5s ease 0s !important;
        }

        .vertical-tab .nav-tabs li a:hover,
        .vertical-tab .nav-tabs li.active a:hover {
            color: #ff0772 !important;
            background-color: transparent !important;
            border: none !important;
            border-radius: none !important;
        }

        .vertical-tab .nav-tabs li.active a {
            color: blue !important;
            border: none !important;
            background-color: transparent !important;
            border-radius: none !important;
        }


        @media only screen and (max-width: 479px) {
            .vertical-tab .nav-tabs {
                width: 100% !important;
                display: block !important;
            }

            .vertical-tab .nav-tabs li a {
                padding: 10px 25px 9px !important;
            }

            .vertical-tab .nav-tabs li:last-child a {
                margin: 0 !important;
            }

            .vertical-tab .nav-tabs li a:before {
                left: 0 !important;
            }

            .vertical-tab .nav-tabs li a:hover:before,
            .vertical-tab .nav-tabs li.active a:before,
            .vertical-tab .nav-tabs li.active a:hover:before {
                background-color: #fff !important;
                left: 10px !important;
            }

            .vertical-tab .tab-content {
                font-size: 14px !important;
                padding: 15px !important;
                display: block !important;
            }
        }
    </style>
</head>

<body>
    <div class="vertical-tab">

        <div class="container-fluid p-0 m-0">
            <div class="row p-0 m-0">
                <div class="col-sm col-md col-lg-2 p-0 m-0">
                    <!-- SideNav card  -->
                    <div class="card shadow-lg rounded-0  sticky p-0 m-0">
                        <div class="card-body p-0 m-0">
                            <!-- Panel -->
                            <div class="panel  bg-dark bg-gradient  text-light p-0 m-0 border-0 rounded-0">
                                <div class="panel-heading text-light rounded-0 ">
                                    <div class="panel-title text-center text-light rounded-0 p-3">
                                        <h5 style="font-weight: bolder;" class="small text-light display-6">ZDAMWU</h5>
                                        <p style="font-size: 10px !important;" class="text-center text-light">Zimabwe Diamond & Allied Minerals Workers Union</p>
                                    </div>
                                </div>
                            </div>
                            <!-- Panel -->
                            <!-- cardheader -->
                            <div class="card-title p-4 border-bottom">
                                <h2 style="font-weight: bolder;" class="text-uppercase text-dark text-center"><strong> dashboard</strong></h2>
                            </div>
                            <!-- End of cardheader -->
                            <!-- Sidebar Navlinks -->
                            <ul class="nav nav-tabs" id="myTab">
                                <li class="nav-item"> <a class="sidebar-link nav-link text-dark" data-toggle="tab" href="#sectionA"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> View All Members</a></li>
                                <li class="nav-item"> <a class="sidebar-link nav-link text-secondary" data-toggle="tab" href="#sectionB"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> Add New Members</a></li>
                                <li class="nav-item"> <a class="sidebar-link nav-link text-secondary" data-toggle="tab" href="#sectionC"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> Invoicing/Billing</a></li>
                                <li class="nav-item"> <a class="sidebar-link nav-link text-secondary" data-toggle="tab" href="##3333333"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> Payments</a></li>
                                <li class="nav-item"> <a class="sidebar-link nav-link text-secondary" data-toggle="tab" href="##4444444"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> Documents</a></li>
                                <li class="nav-item"> <a class="sidebar-link nav-link text-secondary" data-toggle="tab" href="##5555555"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> Calender</a></li>
                                <li class="nav-item"> <a class="sidebar-link nav-link text-secondary" data-toggle="tab" href="##6666666"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> Manage Members</a></li>
                                <li class="nav-item"> <a class="sidebar-link nav-link text-secondary" data-toggle="tab" href="##7777777"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> Add New Users</a></li>
                                <li class="nav-item"> <a class="sidebar-link nav-link text-secondary" data-toggle="tab" href="##8888888"> <i style="font-size: 13px !important;" class="fa fa-folder text-warning"></i> Account Settings</a></li>
                            </ul>
                            <!-- Sidebar Navlinks -->
                        </div>
                        <!-- card footer -->
                        <div class="card-footer p-4 border-top bg-white text-center">
                            <a style="text-decoration:none;" href="../auth/server.php?logout=<?php echo 'logout'; ?>" class="text-uppercase text-dark"><strong><i style="font-size: 10px !important;" class="glyphicon glyphicon-log-out text-warning"></i> Sign out</strong></a>

                            <!-- Footer section -->
                            <?php include('../includes/footer.php') ?>
                            <!-- End of Footer Section -->
                        </div>
                        <!-- End of card footer -->
                    </div>
                    <!-- End of SideNav card -->
                </div>
                <div class="col-sm col-md col-lg-10">
                    <div class="tab-content">
                        <div id="sectionA" class="tab-pane active">
                            <?php
                            $email2 = $_SESSION['email'];
                            $res = mysqli_query($con, "SELECT * FROM  adminstration_users WHERE email='$email2'");
                            if (mysqli_num_rows($res) > 0) {
                                while ($row = mysqli_fetch_assoc($res)) {
                            ?>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-sm col-md col-lg p-3">
                                                <div class="text-center">
                                                    <span><strong style="font-weight: bolder !important;font-size:large;" class="text-uppercase">ADMINSTRATion NAME: </strong><span class="display-6">&ensp;<?php echo $row['admin_name']; ?></span></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php }
                            }
                            ?>
                            <!-- Data_table  -->
                            <div class="panel panel-default text-light ">
                                <div class="panel-heading   bg-dark bg-gradient text-light">
                                    <div class="panel-title text-light"> <i class="fa fa-folder-open text-warning"></i> View All Members</div>
                                    <p class="small text-light">List of all members who have registered with Zimbabwe Diamond & Allied Minerals Workers Union.</p>
                                </div>
                                <div class="panel-body ">
                                    <div class="table-responsive">
                                        <table class="table table-striped " id="myTable">
                                            <thead class="bg-warning bg-gradient ">
                                                <tr style="font-size: xx-small !important;" class="">
                                                    <th scope="col">Membership #</th>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Surname</th>
                                                    <th scope="col">Gender</th>
                                                    <th scope="col">Mine</th>
                                                    <th scope="col">Contact</th>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">Worker #</th>
                                                    <th scope="col">DOB</th>
                                                    <th scope="col">Position</th>
                                                    <th scope="col">Date Joined</th>
                                                    <th scope="col">Job Grade</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $allUsers = $db->query("SELECT  members_registered.mbr_number,members_registered.mbr_fname, members_registered.mbr_surname,members_registered.gender,members_registered.contact,members_registered.mbr_dob,members_registered.mbr_id_number,members_registered.position,members_registered.date_joined,members_registered.work_number,members_registered.job_grade, branch.branch_name
                                                                        FROM members_registered
                                                                        JOIN branch
                                                                        ON members_registered.branch_id = branch.branch_id");
                                                $fetch = $allUsers->fetchAll(PDO::FETCH_OBJ);
                                                foreach ($fetch as $data) {

                                                ?>
                                                    <tr class="border-0" style="font-size: xx-small;">
                                                        <td class="border-0"><?php echo $data->mbr_number ?></td>
                                                        <td class="border-0"><?php echo $data->mbr_fname ?></td>
                                                        <td class="border-0"><?php echo $data->mbr_surname ?></td>
                                                        <td class="border-0"><?php echo $data->gender ?></td>
                                                        <td class="border-0"><?php echo $data->branch_name ?></td>
                                                        <td class="border-0"><?php echo $data->contact ?></td>
                                                        <td class="border-0"><?php echo $data->mbr_id_number ?></td>
                                                        <td class="border-0"><?php echo $data->work_number ?></td>
                                                        <td class="border-0"><?php echo $data->mbr_dob ?></td>
                                                        <td class="border-0"><?php echo $data->position ?></td>
                                                        <td class="border-0"><?php echo $data->date_joined ?></td>
                                                        <td class="border-0"><?php echo $data->job_grade ?></td>

                                                    </tr>
                                                <?php

                                                }
                                                ?>
                                            </tbody>
                                            <tfoot class="bg-warning bg-gradient text-muted">
                                                <tr style="font-size: xx-small !important;" class="">
                                                    <th scope="col">Membership #</th>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Surname</th>
                                                    <th scope="col">Gender</th>
                                                    <th scope="col">Mine</th>
                                                    <th scope="col">Contact</th>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">Worker #</th>
                                                    <th scope="col">DOB</th>
                                                    <th scope="col">Position</th>
                                                    <th scope="col">Date Joined</th>
                                                    <th scope="col">Job Grade</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>

                                </div>
                            </div>
                            <!-- End of Data_table -->
                        </div>
                        <div id="sectionB" class="tab-pane">
                            <h3>Section B</h3>
                            <p>
                                Aku anak indonesia, tubuhku kuat, karena mama memberiku sakatonik abc. bukan baterai abc
                            </p>
                        </div>
                        <div id="sectionC" class="tab-pane">
                            <h3>Section C</h3>
                            <p>
                                Aku anak indonesia, tubuhku kuat, karena mama memberiku sakatonik abc. bukan baterai abc
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script>
        $(document).ready(function() {
            $('a[data-toggle="tab"]').on("show.bs.tab", function(e) {
                localStorage.setItem("activeTab", $(e.target).attr("href"));
            });
            var activeTab = localStorage.getItem("activeTab");
            if (activeTab) {
                $('#myTab a[href="' + activeTab + '"]').tab("show");
            }
        });
    </script>
</body>

</html>