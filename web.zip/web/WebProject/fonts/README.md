The recommended way to use the Material Icons font is by linking to the web font hosted on Google Fonts:

```html
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
```

Read more in our full usage guide:
http://google.github.io/material-design-icons/#icon-font-for-the-web
